#!/system/bin/sh

if [ "$1" == "ip" ]; then
setprop persist.adb.tcp.port 5555
elif [ "$1" == "usb" ]; then
setprop persist.adb.tcp.port ""
else
echo "Usage: ip-adb.sh { ip | usb } adb over IP or USB"
fi





