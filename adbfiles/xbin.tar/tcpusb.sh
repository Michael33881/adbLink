#!/system/bin/sh
setprop persist.adb.tcp.port ""

