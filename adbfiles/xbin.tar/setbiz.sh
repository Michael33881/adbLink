#!/system/bin/sh

cd /data/local/tmp/adblink

./busybox --install -s .


