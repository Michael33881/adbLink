#!/system/bin/sh
export PATH=$PATH:/data/local/tmp/adblink
/system/bin/sh

