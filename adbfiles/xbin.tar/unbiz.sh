#!/system/bin/sh

cd /data/local/tmp/adblink

for f in $(/data/local/tmp/adblink/busybox find /data/local/tmp/adblink -type l) ; 
do 
 bblnk=$(/data/local/tmp/adblink/busybox readlink $f) ; 
  if echo "$bblnk" | /data/local/tmp/adblink/busybox grep -q busybox ;
  then
   /data/local/tmp/adblink/busybox rm $f
  fi ;
done

