#!/system/bin/sh
setprop persist.adb.tcp.port 5555
