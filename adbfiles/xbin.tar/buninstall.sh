#!/system/bin/sh

mount -o remount,rw /system

cd /data/local/tmp/adblink

if [ -e "/data/local/tmp/adblink/mntdata.sh" ];
 then
 mv /data/local/tmp/adblink/mntdata.sh /data/local/tmp/adblink/mntdata.backup;
fi

rm 01sleep
rm 02mntdrives
rm mntdata.orig
rm mntdrives.sh
rm mntdrives1.sh
rm mntdrives2.sh
rm mount.exfat-fuse
rm mount_ufsd_fuse
rm ntfs-3g
rm ntfsfix
rm probe
rm remount
rm rootmnt
rm setbiz.sh
rm unbiz.sh
rm busybox
rm ip-adb.sh
rm mkshrc
rm changepath.sh
rm ip-adb.sh
rm setbiz.sh
rm tcpadb.sh
rm tcpusb.sh
rm unbiz.sh


rm buninstall.sh

mount -o remount,ro /system

